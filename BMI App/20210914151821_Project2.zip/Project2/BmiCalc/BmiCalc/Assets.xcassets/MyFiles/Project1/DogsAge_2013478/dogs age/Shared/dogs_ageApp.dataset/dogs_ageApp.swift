//
//  dogs_ageApp.swift
//  Shared
//
//  Created by english on 2021-09-09.
//

import SwiftUI

@main
struct dogs_ageApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
            
