//
//  ViewController.swift
//  BmiCalc
//
//  Created by english on 2021-09-14.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

